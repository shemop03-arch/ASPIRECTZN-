# ASPIRE LiveStore

A responsive ASPIRE customer storefront plus a separate admin dashboard.

## Files
- `index.html` — customer storefront
- `admin.html` — store dashboard
- `assets/` — the five supplied product pictures
- `config.js` — Supabase and optional WhatsApp settings
- `supabase-setup.sql` — database table, security policies and starter products

## Preview first
Open `index.html` to preview the customer store. Open `admin.html` to edit in local preview mode. Without Supabase, changes are saved only in that browser/device.

## Make it live for every customer (Supabase)
1. Create a Supabase project at https://supabase.com/ .
2. In Supabase, open **SQL Editor**, paste all of `supabase-setup.sql`, and run it.
3. Open **Project Settings → API**. Copy the Project URL and the **anon/public** key (never use the service_role/secret key in website code).
4. Paste those two values into `config.js` as `supabaseUrl` and `supabaseAnonKey`.
5. In Supabase **Authentication → Users**, create your admin account. Use a strong password and keep it private.
6. Deploy the whole `ASPIRE_LiveStore` folder to your hosting provider (Cloudflare Pages, GitHub Pages, Netlify, etc.). Keep the folder structure intact.
7. Visit `/admin.html`, sign in, make edits, then press **Publish changes**. The customer storefront reads the shared database and receives live updates.

Security note: the SQL lets anyone read the public store, but only authenticated users update it. Do not put a Supabase service-role key in `config.js`, HTML, or GitHub. For a production business, restrict admin account creation in Supabase Auth and use a trusted adult's help to manage account/security settings.

## Optional WhatsApp checkout
In `config.js`, set `whatsappNumber` to your store's WhatsApp number in international digits-only format (for Nigeria, start with 234; omit `+`). Checkout opens a pre-filled order message. No payment is collected by this starter site.

## Product photos and logo
Starter products use the five uploaded photos. To change a product image, enter a hosted image URL or a relative image path in its Image URL/path field. To add a custom logo image instead of text, upload the logo into `assets/` and update the storefront header markup/CSS. The dashboard currently edits the logo text or logo image URL, theme, store copy, Snapchat handle, and product catalogue.


## Supabase connection already filled in
The supplied project URL, publishable key, and JWKS URL have been added to `config.js` and `wrangler.toml`.
The publishable key is intended for browser use; do not replace it with a secret/service-role key.

## Backend publishing endpoint
- `functions/api/publish.js` uses `@supabase/server` to verify the signed-in user's Bearer JWT before accepting a store update.
- `package.json` includes `@supabase/server` and Wrangler.
- `wrangler.toml` contains the non-secret Supabase project settings for Cloudflare Pages.
- The admin dashboard signs in through Supabase Auth and sends Publish changes through `/api/publish`.

## Deploy to Cloudflare Pages
1. Upload/push the **contents** of this folder to a GitHub repository (keep `functions/`, `assets/`, and all root files).
2. In Cloudflare Pages, connect that repository. Use build command `npm install` and build output directory `.`. Make sure Functions are enabled by deploying from the project root.
3. If you deploy using Wrangler, run `npm install`, then `npx wrangler pages deploy .`.
4. In Supabase SQL Editor, run `supabase-setup.sql`.
5. In Supabase Authentication settings, disable public sign-ups if only you should have an admin account. Create your admin user yourself and keep its password private.
6. Open `/admin.html`, sign in, edit the store, then press Publish changes.

The server function accepts only authenticated requests. The database's `authenticated` update policy means any signed-in account can publish if public sign-ups are left enabled; turn public sign-ups off and only create the admin account. For a stronger multi-admin setup, add an admin-role check using Supabase app metadata and an RLS policy.

## Important distinction
`@supabase/server` is a backend package for validating incoming Bearer-token requests; the storefront still uses `@supabase/supabase-js` from its CDN for browser sign-in and live database reads. The JWKS URL is used by the backend to verify Auth JWT signatures.


## Upload product photos directly (no image URL needed)

1. Open the Supabase dashboard for the same ASPIRE project.
2. Go to **SQL Editor → New query**.
3. Open `supabase-storage-setup.sql` from this project, copy all its contents, paste into the PostgreSQL SQL Editor, and run it once. This creates the public `aspire-products` Storage bucket and allows signed-in users to upload images.
4. Deploy the updated project files to Cloudflare Pages.
5. Open `/admin.html`, sign in with the Supabase admin account, then choose an image from your device in the **Product photo** field. On iPad, this opens the Photos/Files picker.
6. Wait for **Image uploaded**, then tap **Publish changes**. The product photo URL is stored automatically in the product record; you do not need to paste a URL.

Logo images can also be selected directly under **Store appearance → Upload logo image**. Images must be 5 MB or smaller and use JPG, PNG, WebP, GIF, or AVIF.

The bucket is public-read so shoppers can load product photos. Only authenticated users can upload, replace, or delete files. Keep Supabase secret/service-role keys out of browser code.
