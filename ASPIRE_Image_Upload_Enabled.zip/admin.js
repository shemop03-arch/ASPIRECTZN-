const D={
 settings:{storeName:"ASPIRE",logoText:"ASPIRE",theme:"lime",heroTitle:"Wear your ambition.",heroText:"Pieces made to stand out. Built for your everyday expression.",eyebrow:"NEW SEASON · ASPIRE",aboutTitle:"More than what you wear.",aboutText:"ASPIRE is for people who move with purpose and make their own lane.",footerText:"Made to move differently.",snapchat:"aspire.hub"},
 products:[
 {id:"p1",name:"Jesus Saves Tee",description:"White graphic tee with bold gothic artwork.",price:22000,image:"assets/jesus-saves.jpeg",category:"Graphic tees",active:true},
 {id:"p2",name:"Superstar White Tee",description:"White tee with star graphic and vintage lettering.",price:20000,image:"assets/superstar-white.jpeg",category:"Graphic tees",active:true},
 {id:"p3",name:"Superstar Sleeveless",description:"Black sleeveless top with statement star graphic.",price:20000,image:"assets/superstar-sleeveless.jpeg",category:"Tops",active:true},
 {id:"p4",name:"Superstar Black Tee",description:"Black tee with oversized star artwork.",price:20000,image:"assets/superstar-black.jpeg",category:"Graphic tees",active:true},
 {id:"p5",name:"Blind Faith Tee",description:"White graphic tee with faith-inspired artwork.",price:22000,image:"assets/blind-faith.jpeg",category:"Graphic tees",active:true}
 ]};
const cfg=window.ASPIRE_CONFIG||{},cloudReady=cfg.supabaseUrl&&!cfg.supabaseUrl.includes("YOUR_")&&cfg.supabaseAnonKey&&!cfg.supabaseAnonKey.includes("YOUR_")&&window.supabase;
const sb=cloudReady?window.supabase.createClient(cfg.supabaseUrl,cfg.supabaseAnonKey):null;
let state=JSON.parse(localStorage.getItem("aspire_state")||"null")||D,session=null;
const $=id=>document.getElementById(id);
const esc=v=>String(v??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
function msg(t){$("saveMessage").textContent=t}
function saveLocal(){localStorage.setItem("aspire_state",JSON.stringify(state))}
async function init(){
 if(sb){const {data}=await sb.auth.getSession();session=data.session;sb.auth.onAuthStateChange((_e,s)=>{session=s;showAuth()});}
 showAuth();
}
function showAuth(){
 const logged=!!session;$("loginPanel").hidden=logged;$("dashboard").hidden=!logged;$("logout").hidden=!logged;
 $("connectionStatus").textContent=sb?"CLOUD CONNECTED":"LOCAL PREVIEW";
 if(logged)loadCloud();
}
async function loadCloud(){
 const {data,error}=await sb.from("store_state").select("data").eq("id",1).single();
 if(data?.data){state=data.data;saveLocal();}else if(error)msg("Could not load cloud store: "+error.message);
 drawAll();
}
$("login").onclick=async()=>{
 if(!sb){$("loginMessage").textContent="Add your Supabase URL and anon key in config.js to enable secure admin login.";return}
 const {data,error}=await sb.auth.signInWithPassword({email:$("email").value,password:$("password").value});
 $("loginMessage").textContent=error?error.message:"Signed in.";session=data.session;showAuth();
};
$("logout").onclick=async()=>{if(sb)await sb.auth.signOut();session=null;showAuth()};
function drawAll(){drawProducts();fillSettings()}
function drawProducts(){
 $("productEditor").innerHTML=state.products.map(p=>`<article class="product-edit" data-id="${esc(p.id)}"><img src="${esc(p.image)}" alt="${esc(p.name)}"><label>Name<input data-field="name" value="${esc(p.name)}"></label><label>Price (NGN)<input data-field="price" type="number" min="0" value="${Number(p.price)}"></label><label class="wide">Description<textarea data-field="description">${esc(p.description)}</textarea></label><label>Product photo<input data-image-upload="${esc(p.id)}" type="file" accept="image/*"><small class="field-hint">Choose from Photos or Files</small></label><label>Category<input data-field="category" value="${esc(p.category||"") }"></label><label><span>Visible to customers</span><input data-field="active" type="checkbox" ${p.active!==false?"checked":""}></label><p class="upload-status" aria-live="polite"></p><button class="danger" data-delete="${esc(p.id)}">Delete</button></article>`).join("");
 document.querySelectorAll(".product-edit input:not([type=file]),.product-edit textarea").forEach(el=>el.onchange=()=>{const card=el.closest(".product-edit"),p=state.products.find(x=>x.id===card.dataset.id);if(el.dataset.field==="active")p.active=el.checked;else if(el.dataset.field==="price")p.price=Number(el.value);else p[el.dataset.field]=el.value;saveLocal()});
 document.querySelectorAll("[data-image-upload]").forEach(input=>input.onchange=async()=>{const file=input.files?.[0];if(!file)return;const card=input.closest(".product-edit"),p=state.products.find(x=>x.id===input.dataset.imageUpload),status=card.querySelector(".upload-status");try{status.textContent="Uploading image…";const url=await uploadImage(file,"products");p.image=url;card.querySelector("img").src=url;saveLocal();status.textContent="Image uploaded. Publish changes to show it to customers.";}catch(err){status.textContent=err.message||"Image upload failed.";}input.value=""});
 document.querySelectorAll("[data-delete]").forEach(b=>b.onclick=()=>{if(confirm("Delete this product?")){state.products=state.products.filter(p=>p.id!==b.dataset.delete);drawProducts();saveLocal()}});
}
async function uploadImage(file,folder){
 if(!sb||!session)throw new Error("Sign in to Supabase first to upload images.");
 if(!["image/jpeg","image/png","image/webp","image/gif","image/avif"].includes(file.type))throw new Error("Choose a JPG, PNG, WebP, GIF, or AVIF image.");
 if(file.size>5*1024*1024)throw new Error("Image is too large. Please choose an image under 5 MB.");
 const ext=(file.name.split(".").pop()||"jpg").toLowerCase().replace(/[^a-z0-9]/g,"")||"jpg";
 const unique=(window.crypto?.randomUUID?.()||Date.now()+"-"+Math.random().toString(36).slice(2));
 const path=`${folder}/${unique}.${ext}`;
 const {error}=await sb.storage.from("aspire-products").upload(path,file,{cacheControl:"3600",contentType:file.type,upsert:false});
 if(error)throw new Error("Upload failed: "+error.message+". Check that the aspire-products bucket and storage policies are set up.");
 return sb.storage.from("aspire-products").getPublicUrl(path).data.publicUrl;
}
function fillSettings(){const s=state.settings;["storeName","logoText","logoImage","theme","customAccent","snapchat","eyebrow","heroTitle","heroText","aboutTitle","aboutText","footerText"].forEach(k=>{if($(k))$(k).value=s[k]??(k==="customAccent"?"#d7ff00":"")})}
function settingsFrom(ids){ids.forEach(k=>state.settings[k]=$(k).value);saveLocal()}
$("addProduct").onclick=()=>{state.products.unshift({id:"p"+Date.now(),name:"New ASPIRE product",description:"Add a product description.",price:0,image:"assets/superstar-white.jpeg",category:"New arrivals",active:true});drawProducts();saveLocal()};
$("logoImageFile").onchange=async()=>{const file=$("logoImageFile").files?.[0];if(!file)return;try{$("logoImageFile").disabled=true;msg("Uploading logo image…");state.settings.logoImage=await uploadImage(file,"logos");saveLocal();msg("Logo uploaded. Tap Save appearance, then Publish changes.");}catch(err){msg(err.message||"Logo upload failed.");}finally{$("logoImageFile").disabled=false;$("logoImageFile").value=""}};
$("saveAppearance").onclick=()=>{settingsFrom(["storeName","logoText","theme","customAccent","snapchat","eyebrow"]);msg("Appearance saved. Publish changes to update the live store.")};
$("saveContent").onclick=()=>{settingsFrom(["heroTitle","heroText","aboutTitle","aboutText","footerText"]);msg("Content saved. Publish changes to update the live store.")};
document.querySelectorAll(".tab").forEach(b=>b.onclick=()=>{document.querySelectorAll(".tab").forEach(x=>x.classList.toggle("active",x===b));["products","appearance","content"].forEach(t=>$(t+"Tab").hidden=t!==b.dataset.tab)});
$("publish").onclick=async()=>{
 saveLocal();
 if(!sb){msg("Saved on this device only. Configure Supabase to publish updates to all customers.");return}
 if(!session){msg("Please sign in first.");return}
 const {data:sessionData}=await sb.auth.getSession();
 const accessToken=sessionData?.session?.access_token;
 if(!accessToken){msg("Your admin session expired. Sign in again.");return}
 try{
   const response=await fetch("/api/publish",{
     method:"PUT",
     headers:{
       "Content-Type":"application/json",
       "Authorization":"Bearer "+accessToken,
       "apikey":cfg.supabaseAnonKey
     },
     body:JSON.stringify({data:state})
   });
   const result=await response.json().catch(()=>({}));
   if(!response.ok){msg("Publish failed: "+(result.error||result.message||"Request rejected ("+response.status+")"));return}
   msg("Published! The customer storefront will receive the updated store data.");
 }catch(err){msg("Could not reach the store backend. Check that the Cloudflare Pages Functions folder was deployed.");}
};
if(!sb){$("loginPanel").hidden=true;$("dashboard").hidden=false;$("logout").hidden=true;drawAll()}else init();