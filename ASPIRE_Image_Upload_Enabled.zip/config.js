// Public browser configuration. Supabase publishable keys are designed for client-side use.
// Never put a Supabase secret/service-role key in this file.
window.ASPIRE_CONFIG = {
  supabaseUrl: "https://nunwtngitywytkjaobjy.supabase.co",
  supabaseAnonKey: "sb_publishable_LC9UJ8ZNvjumK6CULgyRDw_-NRzpC5q",
  jwksUrl: "https://nunwtngitywytkjaobjy.supabase.co/auth/v1/.well-known/jwks.json",
  whatsappNumber: ""
};
