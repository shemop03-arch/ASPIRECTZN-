import { withSupabase } from "@supabase/server";

export async function onRequest({ request, env }) {
  const supabaseEnv = {
    url: env.SUPABASE_URL,
    publishableKeys: { default: env.SUPABASE_PUBLISHABLE_KEY },
    secretKeys: {},
    jwks: new URL(env.SUPABASE_JWKS_URL)
  };

  const handler = withSupabase(
    { auth: "user", env: supabaseEnv },
    async (req, ctx) => {
      if (req.method !== "PUT") {
        return Response.json({ error: "Method not allowed" }, { status: 405 });
      }

      let payload;
      try {
        payload = await req.json();
      } catch {
        return Response.json({ error: "Invalid JSON body" }, { status: 400 });
      }

      if (!payload || !payload.data || typeof payload.data !== "object") {
        return Response.json({ error: "Store data is required" }, { status: 400 });
      }

      const { error } = await ctx.supabase
        .from("store_state")
        .update({
          data: payload.data,
          updated_at: new Date().toISOString()
        })
        .eq("id", 1);

      if (error) {
        return Response.json({ error: error.message }, { status: 403 });
      }

      return Response.json({ ok: true });
    }
  );

  return handler(request);
}
