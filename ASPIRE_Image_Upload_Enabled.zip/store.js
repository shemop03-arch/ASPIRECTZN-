const DEFAULT_STATE={
 settings:{storeName:"ASPIRE",logoText:"ASPIRE",theme:"lime",heroTitle:"Wear your ambition.",heroText:"Pieces made to stand out. Built for your everyday expression.",eyebrow:"NEW SEASON · ASPIRE",aboutTitle:"More than what you wear.",aboutText:"ASPIRE is for people who move with purpose and make their own lane.",footerText:"Made to move differently.",snapchat:"aspire.hub"},
 products:[
 {id:"p1",name:"Jesus Saves Tee",description:"White graphic tee with bold gothic artwork.",price:22000,image:"assets/jesus-saves.jpeg",category:"Graphic tees",active:true},
 {id:"p2",name:"Superstar White Tee",description:"White tee with star graphic and vintage lettering.",price:20000,image:"assets/superstar-white.jpeg",category:"Graphic tees",active:true},
 {id:"p3",name:"Superstar Sleeveless",description:"Black sleeveless top with statement star graphic.",price:20000,image:"assets/superstar-sleeveless.jpeg",category:"Tops",active:true},
 {id:"p4",name:"Superstar Black Tee",description:"Black tee with oversized star artwork.",price:20000,image:"assets/superstar-black.jpeg",category:"Graphic tees",active:true},
 {id:"p5",name:"Blind Faith Tee",description:"White graphic tee with faith-inspired artwork.",price:22000,image:"assets/blind-faith.jpeg",category:"Graphic tees",active:true}
 ]};
const cfg=window.ASPIRE_CONFIG||{};
const cloudReady=cfg.supabaseUrl&&!cfg.supabaseUrl.includes("YOUR_")&&cfg.supabaseAnonKey&&!cfg.supabaseAnonKey.includes("YOUR_")&&window.supabase;
const sb=cloudReady?window.supabase.createClient(cfg.supabaseUrl,cfg.supabaseAnonKey):null;
let state=JSON.parse(localStorage.getItem("aspire_state")||"null")||DEFAULT_STATE;
let cart=[];
const $=id=>document.getElementById(id);
const money=n=>"₦"+Number(n||0).toLocaleString("en-NG");
function saveLocal(){localStorage.setItem("aspire_state",JSON.stringify(state))}
function notify(msg){const t=$("toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2100)}
async function loadState(){
 if(!sb){render();return}
 const {data,error}=await sb.from("store_state").select("data").eq("id",1).maybeSingle();
 if(data?.data){state=data.data;saveLocal()}else if(error){console.warn(error);notify("Cloud not connected — showing preview")}
 render();
 sb.channel("aspire-live-store").on("postgres_changes",{event:"UPDATE",schema:"public",table:"store_state",filter:"id=eq.1"},payload=>{state=payload.new.data;saveLocal();render();notify("Store updated")}).subscribe();
}
async function publish(){
 saveLocal();
 if(sb){const {error}=await sb.from("store_state").update({data:state,updated_at:new Date().toISOString()}).eq("id",1);if(error){console.error(error);notify("Cloud save failed — check admin access")}else notify("Published live to customers")}
 else notify("Saved on this device. Connect Supabase for customer-wide live updates.");
}
function render(){
 const s=state.settings||DEFAULT_STATE.settings;
 const brandMarkup=(s.logoImage?`<img class="logo-image" src="${esc(s.logoImage)}" alt="${esc(s.logoText||s.storeName)}">`:esc(s.logoText||s.storeName))+"<span>.</span>";
 document.documentElement.style.setProperty("--accent",({lime:"#d7ff00",red:"#ff3b30",blue:"#72a7ff",pink:"#ff9ecb",orange:"#ff8b35",mono:"#d8d8d8"}[s.theme]||s.customAccent||"#d7ff00"));
 $("brandName").innerHTML=brandMarkup;$("footerBrand").innerHTML=brandMarkup;
 $("heroTitle").innerHTML=(s.heroTitle||"Wear your ambition.").replace("ambition.","<em>ambition.</em>").replace(/\n/g,"<br>");
 $("heroText").textContent=s.heroText||"";$("eyebrow").textContent=s.eyebrow||"";
 $("aboutTitle").textContent=s.aboutTitle||"";$("aboutText").textContent=s.aboutText||"";$("footerText").textContent=s.footerText||"";
 $("snapLink").textContent="Snapchat @"+(s.snapchat||"aspire.hub")+" ↗";$("snapLink").href="https://www.snapchat.com/add/"+(s.snapchat||"aspire.hub").replace("@","");
 $("year").textContent=new Date().getFullYear();
 const products=(state.products||[]).filter(p=>p.active!==false);
 $("productCount").textContent=products.length+" PRODUCTS";
 $("productGrid").innerHTML=products.map(p=>`<article class="product-card"><img class="product-image" src="${esc(p.image)}" alt="${esc(p.name)}"><div class="product-info"><div><h3>${esc(p.name)}</h3><p>${esc(p.description||"")}</p></div><span class="price">${money(p.price)}</span></div><button class="add-btn" data-add="${esc(p.id)}">Add to bag +</button></article>`).join("");
 document.querySelectorAll("[data-add]").forEach(b=>b.onclick=()=>addCart(b.dataset.add));
 updateCart();
}
function esc(v){return String(v??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]))}
function addCart(id){const p=state.products.find(x=>x.id===id);if(!p)return;cart.push(p);updateCart();notify("Added to your bag")}
function updateCart(){
 $("cartCount").textContent=cart.length;$("cartTotal").textContent=money(cart.reduce((a,p)=>a+Number(p.price),0));
 $("cartItems").innerHTML=cart.length?`<div class="cart-lines">${cart.map((p,i)=>`<div class="cart-line"><img src="${esc(p.image)}"><div><h4>${esc(p.name)}</h4><p>${money(p.price)}</p><button class="remove-item" data-remove="${i}">Remove</button></div></div>`).join("")}</div>`:"<p>Your bag is empty.</p>";
 document.querySelectorAll("[data-remove]").forEach(b=>b.onclick=()=>{cart.splice(Number(b.dataset.remove),1);updateCart()});
}
$("cartButton").onclick=()=>$("cartOverlay").classList.add("open");$("closeCart").onclick=()=>$("cartOverlay").classList.remove("open");
$("cartOverlay").onclick=e=>{if(e.target===$("cartOverlay"))$("cartOverlay").classList.remove("open")};
$("checkoutBtn").onclick=()=>{
 if(!cart.length){notify("Your bag is empty");return}
 if(!cfg.whatsappNumber){notify("Store WhatsApp number is not set yet");return}
 const lines=cart.map(p=>`${p.name} — ${money(p.price)}`).join("%0A");
 const total=money(cart.reduce((a,p)=>a+Number(p.price),0));
 window.open(`https://wa.me/${cfg.whatsappNumber}?text=${encodeURIComponent("Hello ASPIRE, I want to order:%0A"+lines+"%0ATotal: "+total)}`,"_blank");
};
loadState();