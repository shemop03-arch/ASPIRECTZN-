-- Run this in Supabase SQL Editor.
create table if not exists public.store_state (
  id integer primary key check (id = 1),
  data jsonb not null,
  updated_at timestamptz not null default now()
);
alter table public.store_state enable row level security;

-- Everyone can read the published storefront.
drop policy if exists "Storefront can read published state" on public.store_state;
create policy "Storefront can read published state"
on public.store_state for select
to anon, authenticated using (true);

-- Only signed-in users can publish. Create admin users yourself in Supabase Auth.
drop policy if exists "Signed-in admins can update store" on public.store_state;
create policy "Signed-in admins can update store"
on public.store_state for update
to authenticated using (true) with check (true);

insert into public.store_state (id, data)
values (1, '{
  "settings": {
    "storeName":"ASPIRE","logoText":"ASPIRE","theme":"lime",
    "heroTitle":"Wear your ambition.",
    "heroText":"Pieces made to stand out. Built for your everyday expression.",
    "eyebrow":"NEW SEASON · ASPIRE",
    "aboutTitle":"More than what you wear.",
    "aboutText":"ASPIRE is for people who move with purpose and make their own lane.",
    "footerText":"Made to move differently.","snapchat":"aspire.hub"
  },
  "products": [
    {"id":"p1","name":"Jesus Saves Tee","description":"White graphic tee with bold gothic artwork.","price":22000,"image":"assets/jesus-saves.jpeg","category":"Graphic tees","active":true},
    {"id":"p2","name":"Superstar White Tee","description":"White tee with star graphic and vintage lettering.","price":20000,"image":"assets/superstar-white.jpeg","category":"Graphic tees","active":true},
    {"id":"p3","name":"Superstar Sleeveless","description":"Black sleeveless top with statement star graphic.","price":20000,"image":"assets/superstar-sleeveless.jpeg","category":"Tops","active":true},
    {"id":"p4","name":"Superstar Black Tee","description":"Black tee with oversized star artwork.","price":20000,"image":"assets/superstar-black.jpeg","category":"Graphic tees","active":true},
    {"id":"p5","name":"Blind Faith Tee","description":"White graphic tee with faith-inspired artwork.","price":22000,"image":"assets/blind-faith.jpeg","category":"Graphic tees","active":true}
  ]
}'::jsonb)
on conflict (id) do nothing;

-- Enable Realtime for instant customer-side updates:
alter publication supabase_realtime add table public.store_state;


-- Explicit Data API privileges for the storefront and authenticated admin.
grant select on public.store_state to anon, authenticated;
grant update on public.store_state to authenticated;
