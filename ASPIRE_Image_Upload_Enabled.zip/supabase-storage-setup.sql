-- ASPIRE image uploads: run this once in the Supabase PostgreSQL SQL Editor.
-- Product and logo images are public so customers can view them on the storefront.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'aspire-products',
  'aspire-products',
  true,
  5242880,
  array['image/jpeg','image/png','image/webp','image/gif','image/avif']
)
on conflict (id) do update set
  public = excluded.public,
  file_size_limit = excluded.file_size_limit,
  allowed_mime_types = excluded.allowed_mime_types;

drop policy if exists "ASPIRE public image read" on storage.objects;
create policy "ASPIRE public image read"
on storage.objects for select
to public using (bucket_id = 'aspire-products');

drop policy if exists "ASPIRE signed-in image upload" on storage.objects;
create policy "ASPIRE signed-in image upload"
on storage.objects for insert
to authenticated with check (bucket_id = 'aspire-products');

drop policy if exists "ASPIRE signed-in image update" on storage.objects;
create policy "ASPIRE signed-in image update"
on storage.objects for update
to authenticated using (bucket_id = 'aspire-products')
with check (bucket_id = 'aspire-products');

drop policy if exists "ASPIRE signed-in image delete" on storage.objects;
create policy "ASPIRE signed-in image delete"
on storage.objects for delete
to authenticated using (bucket_id = 'aspire-products');
